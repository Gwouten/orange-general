// /* Fetch any embeddable Twitter object from the OEmbed API */

// const baseURL            = "https://api.twitter.com/1.1/statuses/update.json";
// const oauth_consumer_key = "";
// const oauth_nonce        = btoa(Date.now().toString());
// const oauth_signature    = ;


// const getTweets = async () => {
//     let oembedResponse = await fetch(new Request('https://api.twitter.com/1.1/statuses/user_timeline.json'));
//     if(oembedResponse.status === 200) {
//         return oembedResponse.json();
//     } else {
//         throw new Error('Could not fetch from Twitter')
//     }
// }

// getTweets().then(res => {
//     console.log(res);
// }).catch(err => {
//     console.log(err);
// })


// Facebook

const accesToken = "";
